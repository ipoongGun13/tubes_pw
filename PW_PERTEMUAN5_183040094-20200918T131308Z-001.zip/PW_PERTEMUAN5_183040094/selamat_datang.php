<?php
$nama_anda = $_POST["nama-anda"]
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>welcome, <?php echo $nama_anda ?></title>
</head>
<body>

	<h2>
		welcome to jungle, <?php echo $nama_anda ?>!
	</h2>

</body>
</html>