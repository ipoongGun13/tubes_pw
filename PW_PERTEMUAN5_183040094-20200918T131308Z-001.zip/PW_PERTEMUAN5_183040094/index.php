<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Contoh Request Post</title>
</head>
<body>
	<form action="selamat_datang.php" method="post">
		<label for="name"> Nama anda:> </label>
		<input type="text" name="nama-anda" id="nama">
		<br>
		<button type="submit" name="submit">kirim</button>
		
	</form>

</body>
</html>