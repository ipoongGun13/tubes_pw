<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>List Nama Presiden RI</title>
</head>
<body>
	<ul>
		<li><a href="salam.php?nama=ir.Soekarno">ir.Soekarno</a></li>
		<li><a href="salam.php?nama=Soeharto">Soeharto</a></li>
		<li><a href="salam.php?nama=B.J. Habibie">B.J. Habibie</a>
		</li>
		<li><a href="salam.php?nama=Abdurahman Wahid">Abdurahman Wahid</a></li>
	</ul>

</body>
</html>